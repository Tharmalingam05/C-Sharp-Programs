﻿using System;
using System.Collections.Generic;
class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---Queue Class In C-Sharp---");
        Console.WriteLine();

        Queue<String> names=new Queue<string>();
        names.Enqueue("Santhosh");
        names.Enqueue("Praveen");
        names.Enqueue("Senthil");
        names.Enqueue("Santhosh");  // It allows duplicate values.

        Console.WriteLine("-------------");

        Console.WriteLine("Peek Element    :"+names.Peek());
        Console.WriteLine("Element Dequeue :"+names.Dequeue());
        Console.WriteLine("After Deque and Peek Element is :"+names.Peek());

        Console.WriteLine("After Dequeuing is :");

        foreach(String str in names)
        {
            Console.WriteLine(str);
        }
    }
}