﻿using System.Collections.Generic;
using System;
using System.Collections;

class Program 
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---Hash-Table in C-Sharp---");
        Console.WriteLine();

        // Hashtable :Key/Value Combination  - Key changeable

        // Array / Arraylist : Key/Value combination  - Key doesn't changeable

        Hashtable ht=new Hashtable();
        ht.Add("id ",7208);
        ht.Add("name ","Santhosh");
        ht.Add("job ","Developer");
        ht.Add("dept ","BE CSE");
        ht.Add("salary ",80000);
        ht.Add("Email ","santhosh@gmail.com");

        Console.WriteLine(ht["id"]);

        foreach(object obj in ht.Keys)
        Console.WriteLine(obj);
        Console.ReadLine();

        foreach(object obj in ht.Values)
        Console.WriteLine(obj);
        Console.ReadLine();

        foreach(object obj in ht)
        Console.WriteLine(obj);
        Console.ReadLine();

        Console.ReadLine();
    }
}