﻿using System;

class Program 
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---Generic in C-Sharp---");
        Console.WriteLine();

        Gen_cls ob=new Gen_cls();
        ob.Add(12,13);
        ob.sub(15,13);

        Console.ReadLine();

        Another ant=new Another();
        ant.Add<int>(12,23);
        ant.sub<float>(15,13);
    }
}