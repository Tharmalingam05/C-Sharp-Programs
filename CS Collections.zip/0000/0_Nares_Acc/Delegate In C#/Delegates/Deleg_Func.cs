using System;
class Deleg_Func
{
    public static int sum(int a ,int b)
    {
        return a+b;
    }

    public static int mul(int a,int b)
    {
        return a*b;
    }
}