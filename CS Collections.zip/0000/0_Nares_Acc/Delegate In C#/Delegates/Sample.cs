using System;
class Sample
{
    int number=100;
    int res=0;
    // public static int Print(int n)
    // {
    //     res=number+n;
    //     return res;
    // }
}