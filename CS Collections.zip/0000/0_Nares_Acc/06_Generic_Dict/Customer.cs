using System.Globalization;
using System;

class Customer : IComparable<Customer>
{
    public int custid{get;set;}
    public string name{get;set;}
    public string city{get;set;}
    public double balance{get;set;}
    
    public int CompareTo(Customer other)
    {
        if(this.custid > other.custid)
            return 1;

        else if(this.custid < other.custid)
            return -1;

        else
            return 0;
    }
}