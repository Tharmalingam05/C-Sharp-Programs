using System;

class Student : IComparable<Student> // Icomparer is another interface
{
    
    public int sid{get;set;}
    public string name{get;set;}
    public int cls{get;set;}
    public double marks{get;set;}

    public int CompareTo(Student other)
    {
        if(this.sid>other.sid)
            return 1;
        
        else if(this.sid< other.sid)
            return -1;

        else 
            return 0;
    }
}

class CompareStudent : IComparer<Student>  // Icomparable is another interface
{
    public int Compare(Student x,Student y)
    {
        if(x.marks>y.marks)
            return -1;

        else if(x.marks<y.marks)
            return 1;

        else 
            return 0;
    }
}