﻿using System.Collections;
using System;

class Program 
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---Array List in C-Sharp---");
        Console.WriteLine();

        ArrayList al=new ArrayList();
        Console.WriteLine(al.Capacity);  // Now, Array capacity 0

        al.Add(100);
        Console.WriteLine(al.Capacity);  // Auto Resize

        al.Add(200);
        al.Add(300);
        al.Add(400);
        al.Add(500);

        Console.WriteLine(al.Capacity);

        // Now Print the all the values in Array

        foreach(Object obj in al)
        {
            Console.Write(obj+" ");
        }
        Console.ReadLine();

        // Now Insert a value in array

        al.Insert(3,350);

        foreach(Object obj in al)
        {
            Console.Write(obj+" ");
        }
        Console.ReadLine();

        // Now remove the element in an array and using index position

        al.Remove(200);
        al.RemoveAt(3);

        foreach(Object obj in al)
        {
            Console.Write(obj+" ");
        }

        Console.ReadLine();
    }
}