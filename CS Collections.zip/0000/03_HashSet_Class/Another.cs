using System;

class Another
{
    public void Print_Display()
    {
        HashSet<String>name=new HashSet<string>(){"Abishek","Harini","Suriya","Mohammed"};

        foreach(string st in name)
        {
            Console.WriteLine(st);
        }
    }
}