﻿using System;
using System.Collections.Generic;

class Program 
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---HashSet in C-Sharp---");
        Console.WriteLine();

        HashSet<string>names=new HashSet<string>();
        names.Add("Santhosh");
        names.Add("Saravana");
        names.Add("Senthil");
        names.Add("Santhosh");

        // Duplicate value doesn't allowed.

        foreach(string st in names)
        {
            Console.WriteLine(st);
        }

        Console.WriteLine("---Another Method In HashSet");

        Another an=new Another();
        an.Print_Display();
    }
}