﻿using System;

class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---List in C-Sharp");
        Console.WriteLine();

        List<String>names=new List<string>();
        names.Add("Santhosh");
        names.Add("Aravinth");
        names.Add("Praveen");
        names.Add("Dinesh");

        foreach(string str in names)
        {
            Console.WriteLine(str);
        }

        Console.WriteLine("---Another Method in List---");

        AnoMet am=new AnoMet();
        am.Display();
    }
}