﻿using System;
class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---Generic Function in C-Sharp---");
        Console.WriteLine();

        /* - Type Safety
           - Code resue,less code
           - Increased Performance */

        GenericClass<string> str=new GenericClass<string>("This is Generic class");
        GenericClass<int> inte=new GenericClass<int>(93);
        GenericClass<char> ch=new GenericClass<char>('A');
        GenericClass<float> flt=new GenericClass<float>(9.101f);

        Console.WriteLine("---------------------");

        GenCls gen=new GenCls();

        gen.Display("Santhosh");
        gen.Display(97);
        gen.Display('A');
    }
}