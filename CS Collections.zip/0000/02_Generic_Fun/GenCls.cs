using System;
class GenCls
{
    public void Display<T>(T msg)
    {
        Console.WriteLine(msg);
    }
}