using System;
class GenericClass<T>   // <T> It specific Generic class 
{
    public GenericClass(T msg)
    {
        Console.WriteLine(msg);
    }
}