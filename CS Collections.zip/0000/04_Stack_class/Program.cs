﻿using System;
using System.Collections.Generic;
class Program
{
    public static void Main(String[] args)
    {
        Console.WriteLine("---Stack In C-Sharp---");
        Console.WriteLine();

        Stack<String> names=new Stack<string>();
        names.Push("Manik");
        names.Push("Logu");
        names.Push("Raja");
        names.Push("Arjun");
        names.Push("Mohan");

        Console.WriteLine("------------");

        Console.WriteLine("Peek Elements :"+names.Peek());
        Console.WriteLine("Pop Elements  :"+names.Pop());
        Console.WriteLine("After pop and push :"+names.Peek());
    }
}