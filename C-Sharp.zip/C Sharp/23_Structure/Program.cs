﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---Structure---");
            Console.WriteLine("Sturece is a one of the class ");
            
        }
    }
}
