using System;

namespace Sample
{
    struct Employee
    {
        public int id;
        public string name;
        public int salary;

        public Employee(int id,string name,int salary)
        {
            this.id=id;
            this.name=name;
            this.salary=salary;
        }

        // public Employee()
        // {}
    }
}