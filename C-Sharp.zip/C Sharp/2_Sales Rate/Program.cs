﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            int jan,feb,mar,tot,avg;

            Console.Write("Enter sales for Jan :");
            jan =Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter sales for Feb :");
            feb=Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter sales for Mar :");
            mar=Convert.ToInt32(Console.ReadLine());

            tot=jan+feb+mar;
            Console.WriteLine($"Total Sales :{tot}");

            avg=tot/3;
            Console.WriteLine($"Average sales :{avg}");

            int inc;

            if(jan>=15 && feb>=15 && mar>=15)
            {
                if(avg>=75)
                {
                inc=tot*25/100;
                }
                else if(avg>=50)
                {
                inc=tot*20/100;
                }
                else if(avg>=25)
                {
                inc=tot*5/100;
                }
                else
                {
                    inc=0;
                }
            }
           
            else
            {
                Console.WriteLine("No Incentive");
                inc=0;
            }
            Console.WriteLine($"Incentive :{inc}");

        }
    }
}





