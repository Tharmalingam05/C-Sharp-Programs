﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
           int[] sales=new int[3];
           string[] months={"Jan","Feb","Mar"};

           for(int i=0;i<months.Length;i++)
           {
            Console.Write($"Enter Sales for {months[i]}:");
            sales[i]=Convert.ToInt32(Console.ReadLine());
           }

           Console.WriteLine("------------------------");

           int tot=0;
           for(int i=0;i<months.Length;i++)
           {
            Console.WriteLine($"{months[i]}  + {sales[i]}");
            tot +=sales[i];
           }
           Console.WriteLine("Total amnt :"+tot);

           Console.WriteLine("--------------------------");

           foreach(int x in sales)
           {
            Console.WriteLine(x);
           }

           Console.WriteLine();
           
           Array.Sort(sales);
           foreach(int x in sales)
           {
            Console.WriteLine("Sorted list :"+x);
           }
        }
    }
}