﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--Interface---");
            // It uses only Public Modifier only and no other modifiers not used.

            MyInterface Obj=new Product();
            Obj.setData();
            Obj.getData();

            Console.WriteLine("-------------------");

            Product pd= new Product();
            pd.setData();
            pd.getData();

        }
    }
}