using System;

namespace Sample
{
    class Product:MyInterface
    {
        int id;
        string name="";
        int price;

        public void getData()
        {
            Console.WriteLine("ID :"+id);
            Console.WriteLine($"Name :{name}");
            Console.WriteLine($"Price :{price}");
        }
        public void setData()
        {
            Console.Write("Enter ID :");
            id=Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter a name :");
            name=Console.ReadLine();

            Console.Write("Enter Credit Score :");
            price=Convert.ToInt32(Console.ReadLine());
        }
        public void storeData()
        {

        }

    }
}