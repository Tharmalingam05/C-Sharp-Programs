using System;

namespace Sample
{
    interface MyInterface
    {
        void getData();
        void setData();
        void storeData();
    }
}