using System;
using System.Collections.Generic;

namespace Sample
{
    class Student 
    {
        public int roll;
        public string name="";
        public int score;

        public Student(int roll,string name,int score)
        {
            // Create a Own constructor

            this.roll=roll;
            this.name=name;
            this.score=score;
        }

        public Student()
        {
            // Empty Constructor
        }

        public void SetData()
        {
            Console.Write("Enter Roll :");
            roll=Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter a name :");
            name=Console.ReadLine();

            Console.Write("Enter a Score :");
            score=Convert.ToInt32(Console.ReadLine());

        }

        public void GetData()
        {
            Console.WriteLine("Roll   :"+roll);
            Console.WriteLine("Name   :"+name);
            Console.WriteLine("Score  :"+score);
        }

        public override string ToString()
        {
            return $"{roll} \t {name}  \t {score}";
        }
    }
}
