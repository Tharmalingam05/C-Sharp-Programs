﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---Object Oriented Proramming---");

            Student s=new Student(7208,"Santhosh",450);
            // s.name="Santhosh";
            // s.roll=20103117;
            // s.score=450;

            Student t=new Student();
            t.name="Sandy";
            t.roll=2010300;
            t.score=480;

            Console.WriteLine(s.name +" "+ s.roll +" "+ s.score);
            Console.WriteLine(t.name+" "+t.roll+" "+t.score);

            Console.WriteLine("----------------------------------");

            s.SetData();
            s.GetData();
            System.Console.WriteLine(s);
        }
    }
}