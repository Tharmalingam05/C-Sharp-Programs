﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---Find the Factorial Numbers---");

            Console.WriteLine("Enter the number :");
            int number=Convert.ToInt32(Console.ReadLine());

            int f=1;

            for(int i=1;i<=number;i++)
            {
                f=f*i;
            }

            Console.WriteLine($"Factorial of {number} is {f}");

        }
    }
}