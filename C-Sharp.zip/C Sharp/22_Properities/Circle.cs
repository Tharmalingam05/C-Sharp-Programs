using System;

namespace Sample
{
    class Circle
    {
        public int r;
        public float pi = 3.14f;

        public void area()
        {
            Console.WriteLine(pi * r * r);

        }

        public int R
        {
            get
            {
                return r;
            }
            set
            {
                if (value > 0)
                    r = value;

                else
                    r = 1;
            }
        }
    }
}
