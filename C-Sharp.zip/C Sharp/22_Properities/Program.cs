﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---Properities in CSharp---");

            Circle cir=new Circle(){r=13,pi=3.14f};
            cir.r=-12;
            cir.area();

            Console.WriteLine("--------------------");

            cir.R=-12;
            cir.area();

            Console.WriteLine("-------------------------");
        }
    }
}