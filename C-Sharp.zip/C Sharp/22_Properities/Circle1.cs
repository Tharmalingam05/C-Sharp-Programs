using System;

namespace Sample
{
    class Circle1
    {
        int r,result;
        float pi=3.14f;
        public void math()
        {
            Console.WriteLine("Enter a Radius number :");
            r=Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Results "+pi * r * r);
        }

        public int val
        {
            get
            {
                return r;
            }
            set
            {
                if(value>0)
                    r=value;

                else
                    r=1;
            }
        }

    }
}