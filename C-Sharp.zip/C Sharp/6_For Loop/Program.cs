﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int i=0;i<=4;i++)
            {
                Console.WriteLine(i);
            }

            Console.WriteLine("-------------------");

            for(int i=1;i<5;i++)
            {
                Console.WriteLine("Hello...");
            }

            Console.WriteLine("-------------------");

            for(int i=1;i<=5;i++)
            {
                Console.WriteLine(i + " EveryOne");
            }

            Console.WriteLine("---------------------");

            for(int i=1;i<=10;i++)
            {
                Console.WriteLine(i +"x"+2+"="+(i*2));
            }
        }
    }
}