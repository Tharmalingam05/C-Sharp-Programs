﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---Instance Modifier---");

            Student s1=new Student(111,"Santhosh",450);
            Student s2=new Student(121,"Sandy",490);

            Console.WriteLine(s1.name);

            Console.WriteLine(s2.name);

            Console.WriteLine("total number of Students :",Student.total_student);
        }
    }
}