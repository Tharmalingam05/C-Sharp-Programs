using System;

namespace Sample
{
    class Student
    {
        static public int total_student;
        public int roll;
        public string name="";
        public int score;

        public Student(int roll,string name,int score)
        {
            this.roll=roll;
            this.name=name;
            this.score=score;
            total_student++;
        }
    }
}