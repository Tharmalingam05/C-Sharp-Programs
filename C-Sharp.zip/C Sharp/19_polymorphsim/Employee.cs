using System;
using System.Collections.Generic;

namespace Sample
{
    class Employee
    {
        public int id;
        public string name="";
        public int salary;

        public Employee(int id,string name,int salary)
        {
            this.id=id;
            this.name=name;
            this.salary=salary;
        }
          public Employee(int id,string name)
        {
            this.id=id;
            this.name=name;
        }
        public Employee()
        {

        }

        public void SetData()
       {
        Console.Write("Enter a id :");
        id=Convert.ToInt32(Console.ReadLine());

        Console.Write("Enter your name :");
        name=Console.ReadLine();

        Console.Write("Enter your salary :");
        salary=Convert.ToInt32(Console.ReadLine());
       }

       public void SetData(int id,string name,int salary)
       {
            this.id=id;
            this.name=name;
            this.salary=salary;
       }

    //    public void GetData()
    //    {
    //     Console.WriteLine("Enter a id :"+id);
    //     Console.WriteLine("Enter a name :"+name);
    //     Console.WriteLine("Enter a Salary :"+salary);
    //    }

       public virtual void display()
       {
            Console.WriteLine(id +" "+name);
       }
    }
}