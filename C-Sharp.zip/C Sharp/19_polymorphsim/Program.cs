﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---Polymorphism---");
            Console.WriteLine("There are two types of Polymorphism ... Complie time Polymorphism and Run time Poly");

            Employee e=new Employee();
            Employee e2=new Employee(112,"Sandy");
            Employee e1=new Employee(111,"Santhosh",45000);

            e.SetData(); //or
            e.SetData(111,"Santhosh",4500);

            Console.WriteLine("---------------------");

            TempEmployee temp=new TempEmployee(121,"Suresh",6000);
            temp.display();

            e.display();
        }

          
    }
}