using System;
using System.Collections.Generic;

namespace Sample
{
    class TempEmployee:Employee
    {
        public TempEmployee(int id,string name,int salary):base(id,name,salary)
        {
            
        }

        public override void display()
        {
            Console.WriteLine("Temp "+id +" "+"Temp "+name);
        }
    }
}