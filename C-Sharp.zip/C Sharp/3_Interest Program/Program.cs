﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            int p , n, r, si;

            Console.Write("Enter the principal value P :");
            p=Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the numbers of years N :");
            n=Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the rate R :");
            r=Convert.ToInt32(Console.ReadLine());

            si=(p*n*r)/100;
            Console.WriteLine($"Simple Interest :{si}");

        }
    }
}






