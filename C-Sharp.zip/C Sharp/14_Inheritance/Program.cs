﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---Student Details---");

            Student s=new Student();

            // s.SetData();
            // s.GetData();

            // Console.WriteLine(s);

            StudentDetails sd=new StudentDetails();
            sd.SetData();
            sd.GetData();
            Console.WriteLine(sd);
            
        }
    }
}