using System;

namespace Sample
{
    class StudentDetails:Student
    {
        int std;
        string sec="";

        // public StudentDetails(int roll,string name,int score,int std,string sec)
        // {
        //     // Create a Constructor

        //     this.std=std;
        //     this.sec=sec;
        // }

        public override void SetData()
        {
            base.SetData();

            Console.Write("Enter a Std :");
            std=Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter a Sec :");
            sec=Console.ReadLine();
        }

        public override void GetData()
        {
            base.GetData();

            Console.WriteLine("Std   :"+std);
            Console.WriteLine("Sec   :"+sec);
        }

        public override string ToString()
        {
            return base.ToString()+$"\t {std} \t {sec}";
        }
    }
}