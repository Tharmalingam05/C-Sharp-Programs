﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the current Reading :");
            int cr=Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the Previous Reading :");
            int pr=Convert.ToInt32(Console.ReadLine());

            int unit=Math.Abs(pr-cr);
            Console.WriteLine($"Current Reading :{unit}");

            Console.WriteLine("Enter the connection type :");
            Console.WriteLine("--------------------------------");
            Console.WriteLine("1.Domestic Type");
            Console.WriteLine("2.International Type");
            Console.WriteLine("3.Custom Type");
            int type=Convert.ToInt32(Console.ReadLine());

            int rate;

            switch(type)
            {
                case 1:
                rate=2;
                break;

                case 2:
                rate=10;
                break;

                case 3:
                rate=6;
                break;

                default:
                Console.WriteLine("Invalid Option");
                rate=0;
                break;
            }

            int amnt=unit*rate;
            Console.WriteLine($"Bill Amount :{amnt}");

        }
    }
}