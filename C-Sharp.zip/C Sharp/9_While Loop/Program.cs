﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---While Loop---");

            int x=0;

            while(x<5)
            {
                Console.WriteLine(x);
                x++;
            }

            Console.WriteLine("-------DO WHILE LOOp--------");

            int y=1;

            do{
                Console.WriteLine(y);
                y++;
            }while(y<=5);


        }
    }
}