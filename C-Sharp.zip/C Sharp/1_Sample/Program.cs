﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to C Sharp programming....");
        }
    }
}





