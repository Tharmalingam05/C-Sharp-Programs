using System;
using System.Collections.Generic;

namespace Sample
{
    class Rectangle:Shape
    {
        public override int area()
        {
            return d1*d2;
        }

        public int get_Perimeter()
        {
            return 2*(d1+d2);
        }
    }
}