using System;
using System.Collections.Generic;

namespace Sample
{
    abstract class Shape
    {
        public int d1,d2;
        public Shape(int d1,int d2)
        {
            this.d1=d1;
            this.d2=d2;
        }

        public Shape()
        {

        }

        public override string ToString()
        {
            return "D1 :"+d1 +"\t"+"D2 :"+d2;
        }

        abstract public int area();
    }
}