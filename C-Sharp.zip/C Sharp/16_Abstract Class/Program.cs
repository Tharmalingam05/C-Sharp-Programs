﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---Abstract Class---");

            // An abstract class often contains abstract methods

            //     - Abstract methods consists of only methods declartions without any method body.

            //     - The non-abstract child of an abstract class must override the abstract methods of the parent.

            //     - Abstract class cannot be instantained.

            Shape s=new Rectangle();
            s.area();
        }
    }
}