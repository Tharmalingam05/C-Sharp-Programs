﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            int cr,pr,type,unit,rate,amnt;

            Console.Write("Enter the Current Reading :");
            cr=Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the previous readling :");
            pr=Convert.ToInt32(Console.ReadLine());

            unit=Math.Abs(cr-pr);
            Console.Write($"Current Reading value is :{unit}");

            Console.WriteLine("Enter the connection type :");
            Console.WriteLine("-------------------------------");
            Console.WriteLine("Domestic Type");
            Console.WriteLine("International Type");
            Console.WriteLine("Custom Type");
            type=Convert.ToChar(Console.ReadLine());

            switch(type)
            {
                case 'D':
                rate=2;
                break;

                case 'I':
                rate=6;
                break;

                case 'C':
                rate=4;
                break;

                default:
                Console.WriteLine("Invalid Option....");
                rate=0;
                break;
            }

            amnt=unit*rate;
            Console.WriteLine($"Bill Amount is :{amnt}");

        }
    }
}