﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number :");
            int n=Convert.ToInt32(Console.ReadLine());

            int result=0;

            for(int i=1;i<=n;i++)
            {
                if(n%2==0)
                {
                    result=1;
                    break;
                }
            }
            if(result==0)
            {
                Console.WriteLine($"{n} is Prime");
            }
            else
            {
                Console.WriteLine($"{n} is not Prime Number");
            }
        }
    }
}