using System;

namespace Sample
{
    class Employee
    {
        public int id,salary;
        public string name;

        public Employee(int id,string name,int salary)
        {
            this.id=id;
            this.name=name;
            this.salary=salary;
        }
        public virtual void display()
        {
            Console.WriteLine(id+" "+name);
        }
    }
}