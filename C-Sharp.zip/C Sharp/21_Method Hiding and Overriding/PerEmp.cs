using System;

namespace Sample
{
    class PerEmp:Employee
    {
        public PerEmp(int id,string name,int salary):base(id,name,salary)
        {
        }

        public override void display()
        {
            Console.WriteLine("per "+id+" "+name);
        }
    }
}