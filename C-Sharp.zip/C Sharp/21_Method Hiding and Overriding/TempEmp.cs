using System;

namespace Sample
{
    class TempEmp:Employee
    {
        public TempEmp(int id,string name,int salary):base(id,name,salary)
        {
        }

        public override void display()
        {
            Console.WriteLine("Temp "+id+" "+name);
        }
    }
}