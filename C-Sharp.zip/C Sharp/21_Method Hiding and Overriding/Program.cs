﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---Overriding---");

            Employee e=new Employee(111,"Santhosh",8000);
            TempEmp temp=new TempEmp(222,"Sandy",90000);
            PerEmp perm=new PerEmp(333,"Suresh",10000);

            Console.WriteLine("---------------------------");

            e.display();
            temp.display();
            perm.display();
        }
    }
}