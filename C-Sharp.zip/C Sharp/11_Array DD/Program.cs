﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---Double Dimensional Array---");

            string[] months={"Jan","Feb","Mar"};
            int[,] sales=new int[3,3];

            for(int i=0;i<sales.GetLength(0);i++)
            {
                Console.WriteLine($"Enter sales for Salesman - {i+1}");

                for(int j=0;j<sales.GetLength(1);j++)
                {
                    Console.Write($"Enter sales for {months[j]}");
                    sales[i,j]=Convert.ToInt32(Console.ReadLine());
                }

                Console.WriteLine("----------------------------------");
            }
        
            for(int i=0;i<sales.GetLength(0);i++)
            {
                Console.Write($"Salesman - {i+1} "+"/t");

                int tot=0;

                for(int j=0;j<sales.GetLength(1);j++)
                {
                    Console.WriteLine($"{sales[i,j]} /t");
                    tot += sales[i,j];
                }
            }
        }
    }
}