﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---Jagged Array---");

            int[][] player=new int[3][];

            for(int i=0;i<player.GetLength(0);i++)
            {
                Console.WriteLine($"Enter Scores for Player - {i+ 1} :");

                Console.Write("Enter Number of Matches played :");
                int n=Convert.ToInt32(Console.ReadLine());

                player[i]=new int[n];

                for(int j=0;j<n;j++)
                {
                    Console.Write($"Enter Score for match {j+ 1}");
                    player[i][j]=Convert.ToInt32(Console.ReadLine());
                }
            }

            for(int i=0;i<player[i].Length;i++)
            {
                Console.WriteLine($"Player - {i+1}  \t");

                int tot=0;

                for(int j=0;j<player[i].Length;i++)
                {
                    Console.WriteLine($"{player[i][j]}  \t");
                    tot +=player[i][j];
                }
                
                Console.WriteLine(tot);
            }
        }
    }
}