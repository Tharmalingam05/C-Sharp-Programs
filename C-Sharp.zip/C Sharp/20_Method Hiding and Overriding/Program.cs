﻿using System;

namespace Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---Method Hiding and Overriding---");

            Employee e=new Employee(1,"Santhosh",90000);
            TempEmp tempemp=new TempEmp(2,"Sandy",85000);
            Per_Employee peremp=new Per_Employee(3,"SriRam",6000);

            e.display();
            tempemp.display();
            peremp.display();
        }
    }
}