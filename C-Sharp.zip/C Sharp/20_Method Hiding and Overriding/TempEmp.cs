using System;

namespace Sample
{
    class TempEmp:Employee
    {
        public TempEmp(int id,string name,int salary):base(id,name,salary)
        {

        }
        public new void display()  // It is know as method hiding
        {
            Console.WriteLine("Temp "+id+" "+"Temp "+name);
        }

        // public override void display()  // It is know as Overriding
        // {
        //     Console.WriteLine("Temp "+id+" "+"Temp "+name);
        // }
    }
}