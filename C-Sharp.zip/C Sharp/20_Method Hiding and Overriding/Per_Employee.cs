using System;

namespace Sample
{
    class Per_Employee:Employee
    {
        public Per_Employee(int id,string name,int salary):base(id,name,salary)
        {

        }
        public new void display()
        {
            Console.WriteLine("Perman "+id+" "+"Perman "+name);
        }
    }
}